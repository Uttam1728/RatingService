

from AdminDashboard import AdminDashboard


if __name__ == "__main__":
    admindashboard = AdminDashboard()
    admindashboard.init()